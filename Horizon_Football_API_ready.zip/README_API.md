# Horizon Football — version API-Football

Cette version prépare la connexion aux données réelles d'API-Football.

## Sécurité
La clé API n'est PAS dans le code du site.
Elle doit être ajoutée comme variable secrète :
`API_FOOTBALL_KEY`

## Déploiement Cloudflare Pages
1. Importer ce projet dans Cloudflare Pages.
2. Ouvrir Settings → Environment variables.
3. Ajouter `API_FOOTBALL_KEY` avec la nouvelle clé API-Football.
4. Redéployer.

Le site appelle ensuite `/api/fixtures`, qui ajoute la clé côté serveur.

## Limites
Le forfait gratuit API-Football est limité à 100 requêtes/jour et 10 requêtes/minute.
Le code utilise un cache de 5 minutes pour éviter de consommer inutilement le quota.

## Étape suivante
Après la connexion, on pourra ajouter progressivement :
- 10 derniers matchs
- domicile/extérieur
- H2H
- statistiques défensives
- cotes pré-match
- filtre Under 2.5 / ligne 2.0
- moteur RETENU / AUCUN RETENU
